/* Documentation
Name:        Shaik Shajara Sharikha
Date:        20/08/2019
Description: A simple shell script which should allow user to register and the registered user to login. After login user
             can take a test on shell. Every activity is stored for further use.
*/

#!/bin/bash

clear
echo -e             "\e[1;3m                             WELCOME TO THE ONLINE TEST \e[0m"
echo "
1.sign up
2.sign in
3.exit
Enter the option "
read option
case $option in
    1)
	echo sign up | ts >> text_activity.log
	echo create username
	read username
	echo Enter passwd of $username
	stty -echo
	read passwd
	stty echo
	if [[ $passwd =~ ^[a-zA-Z0-9]+$ ]]
	then
	    echo Re-enter the passwd for $username
	    stty -echo
	    read pass
	    stty echo
	    if [ $pass = $passwd ]
	    then
		echo $username $passwd >> user.csv
	    else
		echo -e "\e[1;31mEntered passwd doesn't match\e[0m"
	    fi
	else
	    echo enter a strong passwd
	fi
	;;
    2)
	echo sign in | ts >> text_activity.log
	echo Enter the username
	read username
	user=($(cat user.csv | cut -d " " -f1))
	function check_pass()
	{
	    line=$(grep -n $username user.csv | cut -d ":" -f1)
	    pass=$(cat user.csv | head -$line | tail +$line | cut -d " " -f2)
	    if [ $pass = $passwd ]
	    then
		test=yes
	    else
		echo -e "\e[1;31mwrong passwd Re-enter the passwd\e[0m"
		stty -echo
		read passwd
		stty echo
		echo
		check_pass
	    fi
	}
	for i in ${user[@]}
	do
	    if [ $i = $username ]
	    then
		echo "Enter $username's passwd"
		stty -echo
		read  passwd
		stty echo
		echo
		check_pass
		echo -e                "\e[0;32m\e[5m                   START THE TEST ALL THE BEST :-)  \e[0m"
		echo Start test | ts >> text_activity.log
		echo
		break
	    fi
	done
	if [ $i != $username ]
	then
	    echo -e "\e[1;31merror : Invalid username\e[0m"
	    echo -e "\e[1;32mPlease sign up to take test\e[0m"
	fi
	if [[ $test = yes ]]
	then
	    a=($(cut -c1-2 question_bank.txt))
	    var=1
	    var1=5
	    while [ $var -le `expr ${#a[@]} + 6` ]
	    do
		head -$var1 question_bank.txt | tail +$var
		s=1
		if [ $s -eq 1 ]
		then
		    limit=10
		    while [ $limit -ne 0 ]
		    do
			read -t 1 answer
			if [ ${#answer} -eq 1 ]
			then
			    break
			fi
			echo -e "\r you have" "\e[1;31m$limit" "\e[0m seconds to enter the answer : Enter your answer \c"
			limit=$((limit-1))
		    done
		    echo
		    if [ $limit -eq 0 ]
		    then
			echo -e "\e[1;31manswer is not entered\e[0m"
			echo Time out
			echo
		    fi
		fi
		head -$var1 question_bank.txt | tail +$var >> $username.csv
		b=($(head -$var question_bank.txt | tail +$var | cut -d "." -f1 ))
		case $b in
		    "1")
			echo For this question e=1 >> $username.csv
			if [[ $answer = a ]]
			then
			    echo "correct answer is (a)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (a)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif  [ $answer != a -a -n ${answer} ]
			then
			    echo "correct answer is (a)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "2")
			if [[ $answer = c ]]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != c -a -n ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "3")
			if [[ $answer = b ]]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != b -a -n ${answer} ]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "4")
			if [[ $answer = b ]]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != b -a -n ${answer} ]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "5")
			if [[ $answer = c ]]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != c -a -n ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "6")
			if [[ $answer = c ]]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != c -a -n ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "7")
			if [[ $answer = a ]]
			then
			    echo "correct answer is (a)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (a)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != a -a -n ${answer} ]
			then
			    echo "correct answer is (a)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "8")
			if [[ $answer = b ]]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != b -a -n ${answer} ]
			then
			    echo "correct answer is (b)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "9")
			if [[ $answer = d ]]
			then
			    echo "correct answer is (d)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			    echo your e=1 >> $username.csv
		    e=1
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (d)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			    echo your e=0 >> $username.csv
		    e=0
			elif [ $answer != d -a -n ${answer} ]
			then
			    echo "correct answer is (d)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    "10")
			if [[ $answer = c ]]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e  "\e[0;32mEntered answer is $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ -z ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mNot entered the answer\e[0m" >> $username.csv
			    echo >> $username.csv
			elif [ $answer != c -a -n ${answer} ]
			then
			    echo "correct answer is (c)" >> $username.csv
			    echo -e "\e[0;31mEntred answer is Wrong $answer\e[0m" >> $username.csv
			    echo >> $username.csv
			fi
			;;
		    *)
			s=0
			;;
		esac
		if [ $limit -eq 0 ]
		then
		    echo "you have not entered an answer" >> $username.csv
		    echo " " >> $username.csv
		fi
		let var=$var+6
		let var1=$var1+6
	    done
    fi
    ;;
    3)
	echo "Exit"
	;;
    *)
	echo choose right option
	;;
esac
echo -e  "\e[1;31m                                        * THANKS TO COMPLETE THE TEST * \e[0m"
echo end the test | ts >> text_activity.log
